import { BrazilPackage, DeploymentEnvironment, DeploymentStack, LambdaAsset, SoftwareType } from '@amzn/pipelines';
import { Construct } from 'constructs';
import { Function, IFunction, Runtime } from 'aws-cdk-lib/aws-lambda';
import { Duration } from 'aws-cdk-lib';
import { LambdaInvoke } from 'aws-cdk-lib/aws-stepfunctions-tasks';
import { StateMachine, TaskInput } from 'aws-cdk-lib/aws-stepfunctions';
import * as sfn from 'aws-cdk-lib/aws-stepfunctions';
import {
  CompositePrincipal,
  ManagedPolicy,
  PolicyDocument,
  PolicyStatement,
  Role,
  ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { Bucket } from 'aws-cdk-lib/aws-s3';

interface ImageProcessingStackProps {
  readonly env: DeploymentEnvironment;
  readonly stage: string;
  readonly inputImageBucket: Bucket;
  readonly objectDetectionResultsBucket: Bucket;
  readonly backgroundRemovalResultsBucket: Bucket;
  readonly lightingAdjustmentResultsBucket: Bucket;
  readonly finalResultsBucket: Bucket;
}

export class ImageProcessingPipelineStack extends DeploymentStack {
  public readonly objectDetectionLambda;
  public readonly backgroundRemovalLambda;
  public readonly lightingAdjustmentLambda;
  public readonly detailEnhancementLambda;
  public readonly objectDetectionLambdaRole: Role;
  public readonly backgroundRemovalLambdaRole: Role;
  public readonly lightingAdjustmentLambdaRole: Role;
  public readonly detailEnhancementLambdaRole: Role;
  public readonly imageProcessingPipeline: StateMachine;
  constructor(scope: Construct, id: string, props: ImageProcessingStackProps) {
    super(scope, id, {
      env: props.env,
      softwareType: SoftwareType.INFRASTRUCTURE,
    });

    this.objectDetectionLambdaRole = new Role(this, `ObjectDetectionLambdaRole-${props.stage}`, {
      roleName: `ObjectDetectionLambdaRole-${props.stage}`,
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.backgroundRemovalLambdaRole = new Role(this, `BackgroundRemovalLambdaRole-${props.stage}`, {
      roleName: `BackgroundRemovalLambdaRole-${props.stage}`,
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.lightingAdjustmentLambdaRole = new Role(this, `LightingAdjustmentLambdaRole-${props.stage}`, {
      roleName: `LightingAdjustmentLambdaRole-${props.stage}`,
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.detailEnhancementLambdaRole = new Role(this, `DetailEnhancementLambdaRole-${props.stage}`, {
      roleName: `DetailEnhancementLambdaRole-${props.stage}`,
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.objectDetectionLambda = new Function(this, `ObjectDetectionLambda-${props.stage}`, {
      functionName: `ObjectDetectionLambda-${props.stage}`,
      handler: 'handlers.object_detection',
      runtime: Runtime.PYTHON_3_9,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('SentinentDemo-1.0'),
        componentName: 'ObjectDetection',
      }),
      environment: {
        stage: props.stage,
        resultBucket: props.objectDetectionResultsBucket.bucketName,
      },
      timeout: Duration.minutes(10),
      role: this.objectDetectionLambdaRole,
    });

    this.backgroundRemovalLambda = new Function(this, `BackgroundRemovalLambda-${props.stage}`, {
      functionName: `BackgroundRemovalLambda-${props.stage}`,
      handler: 'handlers.background_removal',
      runtime: Runtime.PYTHON_3_9,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('SentinentDemo-1.0'),
        componentName: 'BackgroundRemoval',
      }),
      environment: {
        stage: props.stage,
        resultBucket: props.backgroundRemovalResultsBucket.bucketName,
      },
      timeout: Duration.minutes(10),
      role: this.backgroundRemovalLambdaRole,
    });

    this.lightingAdjustmentLambda = new Function(this, `LightingAdjustmentLambda-${props.stage}`, {
      functionName: `LightingAdjustmentLambda-${props.stage}`,
      handler: 'handlers.lighting_adjustment',
      runtime: Runtime.PYTHON_3_9,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('SentinentDemo-1.0'),
        componentName: 'LightingAdjustment',
      }),
      environment: {
        stage: props.stage,
        resultBucket: props.lightingAdjustmentResultsBucket.bucketName,
      },
      timeout: Duration.minutes(10),
      role: this.lightingAdjustmentLambdaRole,
    });

    this.detailEnhancementLambda = new Function(this, `DetailEnhancementLambda-${props.stage}`, {
      functionName: `DetailEnhancementLambda-${props.stage}`,
      handler: 'handlers.detail_enhancement',
      runtime: Runtime.PYTHON_3_9,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('SentinentDemo-1.0'),
        componentName: 'DetailEnhancement',
      }),
      environment: {
        stage: props.stage,
        resultBucket: props.finalResultsBucket.bucketName,
      },
      timeout: Duration.minutes(10),
      role: this.detailEnhancementLambdaRole,
    });

    const objectDetectionTask = new LambdaInvoke(this, 'ObjectDetectionTask', {
      lambdaFunction: this.objectDetectionLambda,
      payload: TaskInput.fromObject({
        imageUrl: sfn.JsonPath.stringAt('$.imageUrl'),
        jobId: sfn.JsonPath.stringAt('$.jobId'),
      }),
      outputPath: '$.Payload',
    });

    const backgroundRemovalTask = new LambdaInvoke(this, 'BackgroundRemovalTask', {
      lambdaFunction: this.backgroundRemovalLambda,
      payload: TaskInput.fromObject({
        imageUrl: sfn.JsonPath.stringAt('$.imageUrl'),
        jobId: sfn.JsonPath.stringAt('$.jobId'),
      }),
      outputPath: '$.Payload',
    });

    const lightingAdjustmentTask = new LambdaInvoke(this, 'LightingAdjustmentTask', {
      lambdaFunction: this.lightingAdjustmentLambda,
      payload: TaskInput.fromObject({
        imageUrl: sfn.JsonPath.stringAt('$.imageUrl'),
        jobId: sfn.JsonPath.stringAt('$.jobId'),
      }),
      outputPath: '$.Payload',
    });

    const detailEnhancementTask = new LambdaInvoke(this, 'DetailEnhancementTask', {
      lambdaFunction: this.detailEnhancementLambda,
      payload: TaskInput.fromObject({
        imageUrl: sfn.JsonPath.stringAt('$.imageUrl'),
        jobId: sfn.JsonPath.stringAt('$.jobId'),
      }),
      outputPath: '$.Payload',
    });

    const definition = objectDetectionTask
      .next(backgroundRemovalTask)
      .next(lightingAdjustmentTask)
      .next(detailEnhancementTask);

    this.imageProcessingPipeline = new StateMachine(this, 'ImageProcessingPipeline', {
      definition,
      stateMachineName: `ImageProcessingPipeline-${props.stage}`,
    });
  }
}
