import { BrazilPackage, DeploymentEnvironment, DeploymentStack, LambdaAsset, SoftwareType } from '@amzn/pipelines';
import { Construct } from 'constructs';
import { Function, Runtime } from 'aws-cdk-lib/aws-lambda';
import {
  CompositePrincipal,
  ManagedPolicy,
  PolicyDocument,
  PolicyStatement,
  Role,
  ServicePrincipal,
} from 'aws-cdk-lib/aws-iam';
import { Duration } from 'aws-cdk-lib';
import {
  EndpointType,
  LambdaIntegration,
  LogGroupLogDestination,
  RequestValidator,
  RestApi,
} from 'aws-cdk-lib/aws-apigateway';
import { LogGroup } from 'aws-cdk-lib/aws-logs';
import { AttributeType, BillingMode, Table, TableEncryption } from 'aws-cdk-lib/aws-dynamodb';

interface ServiceStackProps {
  readonly env: DeploymentEnvironment;
  readonly stage: string;
  readonly imageProcessingPipelineArn: string;
}

export class ServiceStack extends DeploymentStack {
  public readonly processImageLambdaFunction;
  public readonly getJobStatusLambda;
  public readonly getProcessedImage;
  public readonly processImageLambdaFunctionRole: Role;
  public readonly getJobStatusLambdaRole: Role;
  public readonly getProcessedImageRole: Role;
  public readonly imageMetadataTable: Table;

  constructor(scope: Construct, id: string, props: ServiceStackProps) {
    super(scope, id, {
      env: props.env,
      softwareType: SoftwareType.LONG_RUNNING_SERVICE,
    });
    this.imageMetadataTable = new Table(this, `ImageMetadata-${props.stage}`, {
      tableName: `ImageMetadataTable-${props.stage}`,
      partitionKey: {
        name: 'jobId',
        type: AttributeType.STRING,
      },
      billingMode: BillingMode.PAY_PER_REQUEST,
      encryption: TableEncryption.AWS_MANAGED,
    });

    const processImageLambdaFunctionRoleName = 'processImageLambdaFunctionRole';
    this.processImageLambdaFunctionRole = new Role(this, processImageLambdaFunctionRoleName, {
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      roleName: processImageLambdaFunctionRoleName,
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.getJobStatusLambdaRole = new Role(this, 'getJobStatusLambdaRole', {
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      roleName: 'getJobStatusLambdaRole',
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.getProcessedImageRole = new Role(this, 'getProcessedImageRole', {
      assumedBy: new CompositePrincipal(new ServicePrincipal('lambda.amazonaws.com')),
      roleName: 'getProcessedImageRole',
      managedPolicies: [
        ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        ManagedPolicy.fromAwsManagedPolicyName('Service-role/AWSLambdaVPCAccessExecutionRole'),
      ],
      inlinePolicies: {
        allAccess: new PolicyDocument({
          statements: [
            new PolicyStatement({
              actions: ['*'],
              resources: ['*'],
            }),
          ],
        }),
      },
    });

    this.processImageLambdaFunction = new Function(this, `ProcessImageLambdaFunction-${props.stage}`, {
      functionName: `ProcessImageLambdaFunction-${props.stage}`,
      description: `Timestamp: ${new Date().toISOString()} `,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('SentinentDemo-1.0'),
        componentName: 'ProcessImage',
      }),
      environment: {
        stage: props.stage,
        region: props.env.region,
        imageProcessingPipelineArn: props.imageProcessingPipelineArn,
        imageMetadataTableName: this.imageMetadataTable.tableName,
      },
      handler: 'handlers.process_image',
      memorySize: 512,
      timeout: Duration.minutes(10),
      runtime: Runtime.PYTHON_3_9,
      role: this.processImageLambdaFunctionRole,
    });

    this.getJobStatusLambda = new Function(this, `GetJobStatusLambda-${props.stage}`, {
      functionName: `GetJobStatusLambda-${props.stage}`,
      description: `Timestamp: ${new Date().toISOString()} `,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('SentinentDemo-1.0'),
        componentName: 'GetJobStatusLambda',
      }),
      environment: {
        stage: props.stage,
      },
      handler: 'handlers.get_job_status',
      memorySize: 512,
      timeout: Duration.minutes(10),
      runtime: Runtime.PYTHON_3_9,
      role: this.getJobStatusLambdaRole,
    });

    this.getProcessedImage = new Function(this, `GetProcessedImage-${props.stage}`, {
      functionName: `GetProcessedImage-${props.stage}`,
      description: `Timestamp: ${new Date().toISOString()} `,
      code: LambdaAsset.fromBrazil({
        brazilPackage: BrazilPackage.fromString('SentinentDemo-1.0'),
        componentName: 'GetProcessedImage',
      }),
      environment: {
        stage: props.stage,
      },
      handler: 'handlers.get_processed_image',
      memorySize: 512,
      timeout: Duration.minutes(10),
      runtime: Runtime.PYTHON_3_9,
      role: this.getProcessedImageRole,
    });

    const apiGateway = new RestApi(this, 'ApiGateway', {
      restApiName: `SentinetDemo-${props.stage}`,
      description: 'API Gateway with Lambda Integration',
      deployOptions: {
        stageName: props.stage,
        accessLogDestination: new LogGroupLogDestination(new LogGroup(this, 'ApiGatewayAccessLogs')),
      },
      endpointConfiguration: {
        types: [EndpointType.REGIONAL],
      },
    });

    const jobIdValidator = new RequestValidator(this, 'JobIdValidator', {
      restApi: apiGateway,
      validateRequestBody: false,
      validateRequestParameters: true,
    });

    const processImageLambdaIntegration = new LambdaIntegration(this.processImageLambdaFunction);
    const getJobStatusLambdaIntegration = new LambdaIntegration(this.getJobStatusLambda);
    const getProcessedImageIntegration = new LambdaIntegration(this.getProcessedImage);

    const processImageLambdaResource = apiGateway.root.addResource('process-image');
    processImageLambdaResource.addMethod('POST', processImageLambdaIntegration);

    const getJobStatusLambdaResource = apiGateway.root.addResource('job-status');
    getJobStatusLambdaResource.addMethod('GET', getJobStatusLambdaIntegration, {
      requestParameters: {
        'method.request.querystring.jobId': true,
      },
      requestValidator: jobIdValidator,
    });

    const getProcessedImageResource = apiGateway.root.addResource('processed-image');
    getProcessedImageResource.addMethod('GET', getProcessedImageIntegration, {
      requestParameters: {
        'method.request.querystring.jobId': true,
      },
      requestValidator: jobIdValidator,
    });
  }
}
