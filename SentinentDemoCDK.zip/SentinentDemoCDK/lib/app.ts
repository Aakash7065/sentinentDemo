#!/usr/bin/env node
import { App } from 'aws-cdk-lib';
import {
  BrazilPackage,
  DeploymentPipeline,
  GordianKnotScannerApprovalWorkflowStep,
  Platform,
  ScanProfile, SoftwareType,
} from '@amzn/pipelines';
import { ServiceStack } from './serviceStack';
import { S3Stack } from './s3Stack';
import { ImageProcessingPipelineStack } from './imageProcessingPipelineStack';
import {MonitoringStack} from "./monitor/monitoring_stack";
import {METRIC_AND_ALARM_CONFIGURATION} from "./monitor/metricAndAlarmConfiguration";

// Set up your CDK App
const app = new App();

const applicationAccount = '597088060305';

const pipeline = new DeploymentPipeline(app, 'Pipeline', {
  account: applicationAccount,
  pipelineName: 'SentinentDemo',
  versionSet: 'SentinentDemo/development',
  versionSetPlatform: Platform.AL2_AARCH64,
  trackingVersionSet: 'live', // Or any other version set you prefer
  bindleGuid: 'amzn1.bindle.resource.35vyr75547schlx34wds6qxxa',
  description: 'Python Lambda basic pipeline managed by CDK',
  pipelineId: '7212079',
  notificationEmailAddress: 'singhmgq@amazon.com',
  selfMutate: true,
});

['SentinentDemo', 'SentinentDemoTests'].forEach((pkg) => pipeline.addPackageToAutobuild(BrazilPackage.fromString(pkg)));

pipeline.versionSetStage.addApprovalWorkflow('VersionSet Workflow').addStep(
  new GordianKnotScannerApprovalWorkflowStep({
    platform: Platform.AL2_X86_64, // https://issues.amazon.com/issues/GK-956
    scanProfileName: ScanProfile.ASSERT_LOW,
  }),
);

const stageName = 'alpha';
const alphaStage = pipeline.addStage(stageName, { isProd: false });
const deploymentGroup = alphaStage.addDeploymentGroup({
  name: 'alphaApplication',
});

const env = pipeline.deploymentEnvironmentFor('597088060305', 'us-west-2');
const s3Stack = new S3Stack(app, `SentinentDemo-S3-${stageName}`, {
  env,
  stage: alphaStage.name,
});
const imageProcessingStack = new ImageProcessingPipelineStack(app, `SentinentDemo-ImageProcessing-${stageName}`, {
  env,
  stage: alphaStage.name,
  inputImageBucket: s3Stack.inputImageBucket,
  objectDetectionResultsBucket: s3Stack.objectDetectionResults,
  lightingAdjustmentResultsBucket: s3Stack.lightingAdjustmentResults,
  backgroundRemovalResultsBucket: s3Stack.backgroundRemovalResults,
  finalResultsBucket: s3Stack.finalResults,
});
const serviceStack = new ServiceStack(app, `SentinentDemo-Service-${stageName}`, {
  env,
  stage: alphaStage.name,
  imageProcessingPipelineArn: imageProcessingStack.imageProcessingPipeline.stateMachineArn,
});
const monitoringStack = new MonitoringStack(app, `SentinentDemo-Monitoring-${stageName}`, {
  softwareType: SoftwareType.INFRASTRUCTURE,
  env,
  stage: alphaStage.name,
  dashboardName: `SentinentDemo-Dashboard-${stageName}`,
  metricAndAlarmConfiguration: METRIC_AND_ALARM_CONFIGURATION(alphaStage.name)
});

deploymentGroup.addStacks(serviceStack, s3Stack, imageProcessingStack, monitoringStack);
