import {DeploymentStack, DeploymentStackProps, SoftwareType } from '@amzn/pipelines';
import { Dashboard } from 'aws-cdk-lib/aws-cloudwatch';
import { createMetric, createWidget } from './alarmsAndDashboardUtils';
import { createAlarm } from './alarm';
import {Construct} from "constructs";

export interface MonitoringStackProps extends DeploymentStackProps {
  readonly stage: string;
  readonly dashboardName: string;
  readonly metricAndAlarmConfiguration: any[];
}

export class MonitoringStack extends DeploymentStack {
  public readonly dashboard: Dashboard;
  constructor(scope: Construct, id: string, props: MonitoringStackProps) {
    super(scope, id, {
      env: props.env,
      softwareType: SoftwareType.INFRASTRUCTURE,
    });
    const dashboardName = `${props.dashboardName}`;
    this.dashboard = new Dashboard(this, dashboardName, {
      dashboardName: dashboardName,
      start: '-P7D',
    });
    for (const metricsWidget of props.metricAndAlarmConfiguration) {
      const matrixArray = [];
      for (const metricsRow of metricsWidget) {
        const metricArray = createMetric(
          metricsRow['metric'],
          metricsRow['namespace'],
          metricsRow['statistic'],
          metricsRow['dimension'],
          metricsRow['period'],
          metricsRow['label'],
        );
        const garphWidget = createWidget(metricsRow['title'], metricArray);
        if (metricsRow['alarmReq']) {
          for (const alarm of metricsRow['alarmDetail']) {
            const alarmName = alarm['alarmName'];
            const alarmConfig = alarm['alarmConfig'];
            const metricIndex = alarm['metricIndex'];
            createAlarm(this, alarmName, metricArray[metricIndex], {
              evaluationPeriods: alarmConfig['alarmEvaluationPeriods'],
              threshold: alarm['alarmThreshold'],
              dataPointsToAlarm: alarmConfig['alarmDataPointsToAlarm'],
              statistic: alarmConfig['alarmStats'],
              actionsEnabled: true,
              missingDate: alarmConfig['missingData'],
              comparison: alarmConfig['comparison'],
            });
          }
        }
        matrixArray.push(garphWidget);
      }
      this.dashboard.addWidgets(...matrixArray);
    }
  }
}
