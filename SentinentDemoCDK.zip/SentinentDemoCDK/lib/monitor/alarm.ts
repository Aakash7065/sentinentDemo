import { Alarm, ComparisonOperator, Metric, TreatMissingData } from 'aws-cdk-lib/aws-cloudwatch';
import { Construct } from 'constructs';
export interface alarmProps {
  readonly evaluationPeriods: number;
  readonly threshold: number;
  readonly dataPointsToAlarm: number;
  readonly statistic: string;
  readonly actionsEnabled: boolean;
  readonly missingDate: TreatMissingData;
  readonly comparison: ComparisonOperator;
}

export const createAlarm = (
  scope: Construct,
  alarmName: string,
  metrics: Metric,
  alarmProp: alarmProps,
): void => {
  const alarm = new Alarm(scope, alarmName, {
    evaluationPeriods: alarmProp.evaluationPeriods,
    alarmDescription: alarmName,
    alarmName: alarmName,
    threshold: alarmProp.threshold,
    comparisonOperator: alarmProp.comparison,
    datapointsToAlarm: alarmProp.dataPointsToAlarm,
    treatMissingData: alarmProp.missingDate,
    metric: metrics,
    actionsEnabled: true,
  });
  alarm.addOkAction()
};
