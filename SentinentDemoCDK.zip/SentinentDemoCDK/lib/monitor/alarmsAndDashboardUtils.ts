import { Duration } from 'aws-cdk-lib';
import { GraphWidget, Metric } from 'aws-cdk-lib/aws-cloudwatch';

export const createMetric = (
  cwMetric: string,
  namespace: string,
  statistic: string,
  dimensions: any[],
  period: Duration,
  label: string[],
): Metric[] => {
  return dimensions.map(
    (dimension, i) =>
      new Metric({
        metricName: cwMetric,
        namespace: namespace,
        statistic: statistic,
        label: label[i],
        period: period,
        dimensionsMap: dimension,
      }),
  );
};

export const createWidget = (title: string, cloudWatchMetric: Metric[]): GraphWidget => {
  return new GraphWidget({
    title: title,
    stacked: false,
    leftYAxis: { showUnits: true },
    left: cloudWatchMetric,
    width: 12,
  });
};
