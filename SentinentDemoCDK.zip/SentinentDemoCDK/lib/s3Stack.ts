import { DeploymentStack } from '@amzn/pipelines';
import { Bucket } from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';

export class S3Stack extends DeploymentStack {
  public readonly inputImageBucket: Bucket;
  public readonly objectDetectionResults: Bucket;
  public readonly backgroundRemovalResults: Bucket;
  public readonly lightingAdjustmentResults: Bucket;
  public readonly finalResults: Bucket;

  constructor(scope: Construct, id: string, props: any) {
    super(scope, id, props);
    this.inputImageBucket = new Bucket(this, `input-image-bucket-${props.stage}`, {
      bucketName: `input-image-bucket-${props.stage}`,
    });
    this.objectDetectionResults = new Bucket(this, `object-detection-results-${props.stage}`, {
      bucketName: `object-detection-results-${props.stage}`,
    });
    this.backgroundRemovalResults = new Bucket(this, `background-removal-results-${props.stage}`, {
      bucketName: `background-removal-results-${props.stage}`,
    });
    this.lightingAdjustmentResults = new Bucket(this, `lighting-adjustment-results-${props.stage}`, {
      bucketName: `lighting-adjustment-results-${props.stage}`,
    });
    this.finalResults = new Bucket(this, `final-results-${props.stage}`, {
      bucketName: `final-results-${props.stage}`,
    });
  }
}
