## Welcome!

This package will help you manage Pipelines and your AWS Infrastructure with the power of CDK!

You can view this package's pipeline, [SentinentDemo](https://pipelines.amazon.com/pipelines/SentinentDemo)

## Development

```bash
brazil ws create --name SentinentDemo
cd SentinentDemo
brazil ws use \
  --versionset SentinentDemo/development \
  --package SentinentDemoCDK
cd src/SentinentDemoCDK
brazil-build
```

## Useful links:

- https://builderhub.corp.amazon.com/docs/native-aws/developer-guide/cdk-pipeline.html
- https://code.amazon.com/packages/PipelinesConstructs/blobs/mainline/--/README.md
- https://code.amazon.com/packages/CDKBuild/blobs/HEAD/--/README.md
- https://docs.aws.amazon.com/cdk/api/latest/versions.html
