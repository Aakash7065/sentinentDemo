import pytest
from unittest.mock import patch, MagicMock
from PIL import Image

from sentinent_demo.constants import constants
from sentinent_demo.handlers.lighting_adjustment import (
    calculate_brightness_factor,
    enhance_image_lighting,
    upload_image_to_s3,
    lighting_adjustment,
)
from test_helper import create_test_image


def test_calculate_brightness_factor():
    # Simulated image with varying brightness
    dark_image = Image.new("RGB", (100, 100), "black")
    bright_image = Image.new("RGB", (100, 100), "white")
    medium_image = Image.new("RGB", (100, 100), "gray")

    assert calculate_brightness_factor(dark_image) > 1.0
    assert calculate_brightness_factor(bright_image) < 1.0
    assert calculate_brightness_factor(medium_image) == 1.0


@patch("sentinent_demo.handlers.lighting_adjustment.s3_client.put_object")
@patch("sentinent_demo.handlers.lighting_adjustment.get_filename_from_s3_url", return_value="image.png")
@patch("sentinent_demo.handlers.lighting_adjustment.get_current_date_time", return_value="2024/11/26")
@patch.dict("os.environ", {constants.RESULT_BUCKET_KEY: "testBucket"})
def test_upload_image_to_s3(mock_get_date, mock_get_filename, mock_put_object):
    mock_put_object.return_value = None

    enhanced_image = Image.new("RGB", (100, 100), "white")
    result = upload_image_to_s3(enhanced_image, "12345", "s3://bucket/image.png")

    assert result == "s3://testBucket/2024/11/26/12345/image.png"


@patch("sentinent_demo.handlers.lighting_adjustment.get_s3_object_from_uri", return_value=b"image_bytes")
@patch("sentinent_demo.handlers.lighting_adjustment.enhance_image_lighting", return_value=Image.new("RGB", (100, 100), "white"))
@patch("sentinent_demo.handlers.lighting_adjustment.upload_image_to_s3", return_value="s3://bucket/enhanced_image.png")
@patch("sentinent_demo.handlers.lighting_adjustment.update_job_status")
@patch("sentinent_demo.handlers.lighting_adjustment.ImageMetadataTable")
def test_lighting_adjustment_success(
    mock_metadata_table, mock_update_status, mock_upload_image, mock_enhance_image, mock_get_s3
):
    event = {"jobId": "12345", "imageUrl": "s3://bucket/original_image.png"}
    context = {}

    result = lighting_adjustment(event, context)

    assert result["jobId"] == "12345"
    assert result["imageUrl"] == "s3://bucket/enhanced_image.png"


@patch("sentinent_demo.handlers.lighting_adjustment.get_s3_object_from_uri")
def test_lighting_adjustment_invalid_event(mock_get_s3):
    with pytest.raises(ValueError):
        lighting_adjustment({"jobId": "12345"}, {})
