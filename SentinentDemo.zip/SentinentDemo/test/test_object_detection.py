import pytest
from unittest.mock import patch, MagicMock
from sentinent_demo.handlers.object_detection import object_detection, detect_main_object, crop_and_resize_image, upload_to_s3
from sentinent_demo.exceptions.exceptions import NoObjectDetectedException


@patch("sentinent_demo.handlers.object_detection.get_s3_object_from_uri")
@patch("sentinent_demo.handlers.object_detection.detect_main_object")
@patch("sentinent_demo.handlers.object_detection.crop_and_resize_image")
@patch("sentinent_demo.handlers.object_detection.upload_to_s3")
@patch("sentinent_demo.handlers.object_detection.ImageMetadataTable")
def test_object_detection_success(
    mock_metadata_table, mock_upload, mock_crop, mock_detect, mock_s3_get
):
    mock_metadata_table.return_value.update_status = MagicMock()
    mock_detect.return_value = {"BoundingBox": {"Left": 0.1, "Top": 0.1, "Width": 0.5, "Height": 0.5}}
    mock_s3_get.return_value = b"fake_image_data"
    mock_crop.return_value = b"cropped_image_data"
    mock_upload.return_value = "s3://bucket/path/to/image.png"

    event = {"jobId": "12345", "imageUrl": "s3://bucket/image.png"}
    context = {}

    response = object_detection(event, context)
    assert response["jobId"] == "12345"
    assert response["imageUrl"] == "s3://bucket/path/to/image.png"

