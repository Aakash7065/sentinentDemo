import pytest
from unittest.mock import patch

from sentinent_demo.handlers.detail_enhancement import (calculate_sharpness, enhance_product_details,
                                                        upload_enhanced_image_to_s3, detail_enhancement)
from test_helper import create_test_image


def test_calculate_sharpness():
    test_image_bytes = create_test_image()
    sharpness = calculate_sharpness(test_image_bytes)
    assert sharpness > 0


@patch("sentinent_demo.handlers.detail_enhancement.calculate_sharpness", return_value=2.0)
def test_enhance_product_details(mock_sharpness):
    test_image_bytes = create_test_image()
    enhanced_bytes = enhance_product_details(test_image_bytes)

    # Ensure output is valid image bytes
    assert isinstance(enhanced_bytes, bytes)


@patch("sentinent_demo.handlers.detail_enhancement.s3_client.put_object")
def test_upload_enhanced_image_to_s3(mock_put_object):
    test_image_bytes = create_test_image()
    mock_put_object.return_value = None

    result_url = upload_enhanced_image_to_s3(test_image_bytes, "job123", "s3://bucket/original.png")
    assert result_url.startswith("s3://")


@patch("sentinent_demo.handlers.detail_enhancement.get_s3_object_from_uri", return_value=create_test_image())
@patch("sentinent_demo.handlers.detail_enhancement.enhance_product_details", return_value=create_test_image())
@patch("sentinent_demo.handlers.detail_enhancement.upload_enhanced_image_to_s3", return_value="s3://bucket/enhanced_image.png")
@patch("sentinent_demo.handlers.detail_enhancement.update_job_status")
@patch("sentinent_demo.handlers.detail_enhancement.ImageMetadataTable")
def test_detail_enhancement_success(mock_metadata, mock_update_status, mock_upload, mock_enhance, mock_get_s3):
    event = {"jobId": "12345", "imageUrl": "s3://bucket/original_image.png"}
    context = {}

    result = detail_enhancement(event, context)

    assert result["jobId"] == "12345"
    assert result["imageUrl"] == "s3://bucket/enhanced_image.png"


@patch("sentinent_demo.handlers.detail_enhancement.get_s3_object_from_uri")
def test_detail_enhancement_invalid_event(mock_get_s3):
    with pytest.raises(ValueError):
        detail_enhancement({"jobId": "12345"}, {})
