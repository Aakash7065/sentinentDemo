import json
import unittest
from unittest.mock import patch, MagicMock
from sentinent_demo.handlers.apis.process_image import (process_image, is_valid_image,
                                                        create_image_metadata, start_image_processing)
from sentinent_demo.models.job_status import JobStatus


class TestImageProcessing(unittest.TestCase):

    @patch('sentinent_demo.handlers.apis.process_image.get_s3_object_from_uri')
    @patch('sentinent_demo.handlers.apis.process_image.Image.open')
    def test_is_valid_image_valid(self, mock_open, mock_get_s3_object_from_uri):
        mock_get_s3_object_from_uri.return_value = b"image_data"
        mock_open.return_value.verify.return_value = None  # No exception means valid image

        result = is_valid_image('s3://bucket/path/to/image.jpg')
        self.assertTrue(result)

    @patch('sentinent_demo.handlers.apis.process_image.get_s3_object_from_uri')
    @patch('sentinent_demo.handlers.apis.process_image.Image.open')
    def test_is_valid_image_invalid(self, mock_open, mock_get_s3_object_from_uri):
        mock_get_s3_object_from_uri.return_value = b"image_data"
        mock_open.side_effect = ValueError("Invalid image")

        with self.assertRaises(ValueError):
            is_valid_image('s3://bucket/path/to/image.jpg')

    @patch('sentinent_demo.handlers.apis.process_image.ImageMetadataTable')
    @patch('sentinent_demo.handlers.apis.process_image.generate_uuid_from_s3_key')
    def test_create_image_metadata(self, mock_generate_uuid, mock_image_metadata_table):
        mock_generate_uuid.return_value = 'fake-job-id'
        image_metadata = create_image_metadata('s3://bucket/path/to/image.jpg')

        self.assertEqual(image_metadata.jobId, 'fake-job-id')
        self.assertEqual(image_metadata.imageUrl, 's3://bucket/path/to/image.jpg')
        self.assertEqual(image_metadata.processingStatus, JobStatus.SUBMITTED.value)

    @patch('sentinent_demo.handlers.apis.process_image.StepFunctionInvoker')
    def test_start_image_processing(self, mock_step_function_invoker):
        mock_invoker = MagicMock()
        mock_step_function_invoker.return_value = mock_invoker

        image_metadata = MagicMock()
        image_metadata.jobId = 'fake-job-id'
        image_metadata.imageUrl = 's3://bucket/path/to/image.jpg'

        start_image_processing(image_metadata)

        mock_invoker.start_execution.assert_called_with(
            input_data={'jobId': 'fake-job-id', 'imageUrl': 's3://bucket/path/to/image.jpg'}
        )

    @patch('sentinent_demo.handlers.apis.process_image.is_valid_image')
    @patch('sentinent_demo.handlers.apis.process_image.create_image_metadata')
    @patch('sentinent_demo.handlers.apis.process_image.ImageMetadataTable')
    @patch('sentinent_demo.handlers.apis.process_image.StepFunctionInvoker')
    def test_process_image(self, mock_step_function_invoker, mock_image_metadata_table, mock_create_image_metadata, mock_is_valid_image):
        mock_is_valid_image.return_value = True
        mock_create_image_metadata.return_value = MagicMock(jobId='fake-job-id', imageUrl='s3://bucket/path/to/image.jpg')
        mock_image_metadata_table.return_value.put_item = MagicMock()
        mock_step_function_invoker.return_value.start_execution = MagicMock()

        event = {
            'body': json.dumps({'image_url': 's3://bucket/path/to/image.jpg'})
        }
        context = {}

        response = process_image(event, context)

        self.assertEqual(response['statusCode'], "200")
        self.assertIn('jobId', json.loads(response['body']))
        mock_image_metadata_table.return_value.put_item.assert_called_once()
        mock_step_function_invoker.return_value.start_execution.assert_called_once()

if __name__ == '__main__':
    unittest.main()
