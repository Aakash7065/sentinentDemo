import json
from unittest.mock import patch
from sentinent_demo.handlers.apis.get_processed_image import get_processed_image
from sentinent_demo.models.job_status import JobStatus


@patch("sentinent_demo.handlers.apis.get_processed_image.ImageMetadataTable")
def test_get_processed_image_success(mock_image_metadata_table):
    result = "s3://background-removal-results-alpha/2024/11/26/5faea7fc-e1c7-572c-be68-95f5e981524d/shoePiar.png"
    # Mock database response
    mock_image_metadata_table.return_value.get_item.return_value = {
        "processingStatus": JobStatus.COMPLETED.value,
        "finalResult": result,
    }

    # Mock event input
    event = {"queryStringParameters": {"jobId": "12345"}}
    context = {}

    # Call the function
    response = get_processed_image(event, context)

    # Assertions
    assert response["statusCode"] == 200
    assert json.loads(response["body"]) == {"processedImageUrl": result}


@patch("sentinent_demo.handlers.apis.get_processed_image.ImageMetadataTable")
def test_get_processed_image_in_progress(mock_image_metadata_table):
    # Mock database response
    mock_image_metadata_table.return_value.get_item.return_value = {
        "processingStatus": JobStatus.AT_OBJECT_DETECTION.value
    }

    # Mock event input
    event = {"queryStringParameters": {"jobId": "12345"}}
    context = {}

    # Call the function
    response = get_processed_image(event, context)

    # Assertions
    assert response["statusCode"] == 202
    assert "error" in json.loads(response["body"])


@patch("sentinent_demo.handlers.apis.get_processed_image.ImageMetadataTable")
def test_get_processed_image_missing_job_id(mock_image_metadata_table):
    # Mock event input with missing jobId
    event = {"queryStringParameters": {}}
    context = {}

    # Call the function
    response = get_processed_image(event, context)

    # Assertions
    assert response["statusCode"] == 400
    assert json.loads(response["body"]) == {"error": "Missing jobId in query parameters"}


@patch("sentinent_demo.handlers.apis.get_processed_image.ImageMetadataTable")
def test_get_processed_image_no_final_result(mock_image_metadata_table):
    # Mock database response with no finalResult
    mock_image_metadata_table.return_value.get_item.return_value = {
        "processingStatus": JobStatus.COMPLETED.value
    }

    # Mock event input
    event = {"queryStringParameters": {"jobId": "12345"}}
    context = {}

    # Call the function
    response = get_processed_image(event, context)

    # Assertions
    assert response["statusCode"] == 404
    assert json.loads(response["body"]) == {"error": "Processed image not found"}


@patch("sentinent_demo.handlers.apis.get_processed_image.ImageMetadataTable")
def test_get_processed_image_internal_error(mock_image_metadata_table):
    # Mock database to raise an exception
    mock_image_metadata_table.return_value.get_item.side_effect = Exception("Database error")

    # Mock event input
    event = {"queryStringParameters": {"jobId": "12345"}}
    context = {}

    # Call the function
    response = get_processed_image(event, context)

    # Assertions
    assert response["statusCode"] == 500
    body = json.loads(response["body"])
    assert body["error"] == "Internal server error"
    assert "details" in body
