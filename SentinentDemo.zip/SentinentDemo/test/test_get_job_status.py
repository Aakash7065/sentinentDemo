import json
from unittest.mock import Mock, patch

from sentinent_demo.constants import constants
from sentinent_demo.handlers.apis.get_job_status import get_job_status


@patch("sentinent_demo.handlers.apis.get_job_status.ImageMetadataTable")
def test_get_job_status_success(mock_image_metadata_table):
    # Mock the database response
    mock_image_metadata_table.return_value.get_item.return_value = {"processingStatus": "COMPLETED"}

    # Mock event input
    event = {
        "queryStringParameters": {"jobId": "12345"}
    }
    context = {}

    # Call the function
    response = get_job_status(event, context)

    # Assertions
    assert response['statusCode'] == 200
    assert json.loads(response['body']) == {"jobStatus": "COMPLETED"}
    mock_image_metadata_table.assert_called_with('alpha', constants.REGION)


@patch("sentinent_demo.handlers.apis.get_job_status.ImageMetadataTable")
def test_get_job_status_missing_job_id(mock_image_metadata_table):
    # Mock event with missing jobId
    event = {
        "queryStringParameters": {}
    }
    context = {}

    # Call the function
    response = get_job_status(event, context)

    # Assertions
    assert response['statusCode'] == 400
    assert json.loads(response['body']) == {"error": "Missing jobId in query parameters"}
    mock_image_metadata_table.assert_not_called()


@patch("sentinent_demo.handlers.apis.get_job_status.ImageMetadataTable")
def test_get_job_status_not_found(mock_image_metadata_table):
    # Mock the database response with no processingStatus
    mock_image_metadata_table.return_value.get_item.return_value = {}

    # Mock event input
    event = {
        "queryStringParameters": {"jobId": "12345"}
    }
    context = {}

    # Call the function
    response = get_job_status(event, context)

    # Assertions
    assert response['statusCode'] == 404
    assert json.loads(response['body']) == {"error": "Job not found or no status available"}
    mock_image_metadata_table.assert_called_with('alpha', constants.REGION)


@patch("sentinent_demo.handlers.apis.get_job_status.ImageMetadataTable")
def test_get_job_status_internal_error(mock_image_metadata_table):
    # Mock the database to raise an exception
    mock_image_metadata_table.return_value.get_item.side_effect = Exception("Database error")

    # Mock event input
    event = {
        "queryStringParameters": {"jobId": "12345"}
    }
    context = {}

    # Call the function
    response = get_job_status(event, context)

    # Assertions
    assert response['statusCode'] == 500
    body = json.loads(response['body'])
    assert body['error'] == "Internal server error"
    assert "details" in body
    mock_image_metadata_table.assert_called_with('alpha', constants.REGION)
