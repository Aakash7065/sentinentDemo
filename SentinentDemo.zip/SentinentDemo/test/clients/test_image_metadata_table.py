import unittest
from unittest.mock import patch, MagicMock
from botocore.exceptions import ClientError
from sentinent_demo.clients.image_metadata_table import ImageMetadataTable


class TestImageMetadataTable(unittest.TestCase):
    @patch("sentinent_demo.clients.image_metadata_table.get_dynamo_client")
    def setUp(self, mock_get_dynamo_client):
        # Mock DynamoDB client and table
        self.mock_dynamo_client = MagicMock()
        self.mock_table = MagicMock()
        mock_get_dynamo_client.return_value = self.mock_dynamo_client
        self.mock_dynamo_client.Table.return_value = self.mock_table

        # Initialize ImageMetadataTable instance
        self.table = ImageMetadataTable(stage="alpha")

    def test_put_item_success(self):
        # Mock successful response from DynamoDB
        self.mock_table.put_item.return_value = {"ResponseMetadata": {"HTTPStatusCode": 200}}

        # Call put_item
        result = self.table.put_item("job123", {"attribute": "value"})

        # Assert success
        self.assertTrue(result)
        self.mock_table.put_item.assert_called_once_with(Item={"jobId": "job123", "attribute": "value"})

    def test_put_item_failure(self):
        # Mock ClientError for put_item
        self.mock_table.put_item.side_effect = ClientError(
            error_response={"Error": {"Code": "ValidationError", "Message": "Invalid input"}},
            operation_name="PutItem"
        )

        # Call put_item
        result = self.table.put_item("job123", {"attribute": "value"})

        # Assert failure
        self.assertFalse(result)

    def test_get_item_success(self):
        # Mock successful response from DynamoDB
        self.mock_table.get_item.return_value = {"Item": {"jobId": "job123", "attribute": "value"}}

        # Call get_item
        result = self.table.get_item("job123")

        # Assert item retrieval
        self.assertEqual(result, {"jobId": "job123", "attribute": "value"})
        self.mock_table.get_item.assert_called_once_with(Key={"jobId": "job123"})

    def test_get_item_not_found(self):
        # Mock no item found in response
        self.mock_table.get_item.return_value = {}

        # Call get_item
        result = self.table.get_item("job123")

        # Assert empty dictionary
        self.assertEqual(result, {})

    def test_update_item_success(self):
        # Mock successful update response from DynamoDB
        self.mock_table.update_item.return_value = {
            "Attributes": {"jobId": "job123", "attribute": "updated_value"}
        }

        # Call update_item
        result = self.table.update_item("job123", {"attribute": "updated_value"})

        # Assert updated attributes
        self.assertEqual(result, {"jobId": "job123", "attribute": "updated_value"})
        self.mock_table.update_item.assert_called_once()

    def test_update_item_failure(self):
        # Mock ClientError for update_item
        self.mock_table.update_item.side_effect = ClientError(
            error_response={"Error": {"Code": "ValidationError", "Message": "Invalid update"}},
            operation_name="UpdateItem"
        )

        # Call update_item and assert exception
        with self.assertRaises(ClientError):
            self.table.update_item("job123", {"attribute": "updated_value"})

    def test_update_item_no_updates(self):
        # Call update_item with empty updates and assert ValueError
        with self.assertRaises(ValueError):
            self.table.update_item("job123", {})

    def test_update_status_success(self):
        # Mock successful response for update_item
        self.mock_table.update_item.return_value = {
            "Attributes": {"jobId": "job123", "processingStatus": "COMPLETED"}
        }

        # Call update_status
        result = self.table.update_status("job123", "COMPLETED")

        # Assert updated status
        self.assertEqual(result, {"jobId": "job123", "processingStatus": "COMPLETED"})

    def test_update_status_with_additional_updates(self):
        # Mock successful response for update_item
        self.mock_table.update_item.return_value = {
            "Attributes": {"jobId": "job123", "processingStatus": "COMPLETED", "attribute": "value"}
        }

        # Call update_status with additional updates
        result = self.table.update_status("job123", "COMPLETED", {"attribute": "value"})

        # Assert updated attributes
        self.assertEqual(
            result, {"jobId": "job123", "processingStatus": "COMPLETED", "attribute": "value"}
        )
