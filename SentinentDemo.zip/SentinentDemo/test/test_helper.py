from io import BytesIO

from PIL import Image
def create_test_image():
    """Helper function to create a test image."""
    image = Image.new("RGB", (100, 100), color="gray")
    buffer = BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()