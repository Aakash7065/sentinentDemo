import base64
import io
import json

import pytest
from unittest.mock import patch, MagicMock

from sentinent_demo.constants import constants
from sentinent_demo.handlers.background_removal import (
    remove_background_with_bedrock,
    save_image_to_s3,
    background_removal,
)


@patch("sentinent_demo.handlers.background_removal.bedrock_client.invoke_model")
def test_remove_background_with_bedrock_success(mock_bedrock):
    mock_response = {
        "body": io.BytesIO(
            json.dumps({"images": [base64.b64encode(b"fake_image_data").decode("utf-8")]}).encode()
        )
    }
    mock_bedrock.return_value = mock_response

    result = remove_background_with_bedrock(b"input_image_bytes")
    assert result == b"fake_image_data"


@patch("sentinent_demo.handlers.background_removal.bedrock_client.invoke_model")
def test_remove_background_with_bedrock_failure(mock_bedrock):
    mock_bedrock.side_effect = Exception("Bedrock failure")

    with pytest.raises(Exception):
        remove_background_with_bedrock(b"input_image_bytes")


@patch("sentinent_demo.handlers.background_removal.s3_client.put_object")
@patch("sentinent_demo.handlers.background_removal.get_current_date_time", return_value="2024/11/26")
@patch("sentinent_demo.handlers.background_removal.get_filename_from_s3_url", return_value="test_image.png")
@patch.dict("os.environ", {constants.RESULT_BUCKET_KEY: "testBucket"})
def test_save_image_to_s3_success(mock_get_filename, mock_get_date, mock_put_object):
    mock_put_object.return_value = None
    result = save_image_to_s3(b"processed_image", "12345", "s3://bucket/original_image.png")

    assert result == "s3://testBucket/2024/11/26/12345/test_image.png"


@patch("sentinent_demo.handlers.background_removal.s3_client.put_object")
def test_save_image_to_s3_failure(mock_put_object):
    mock_put_object.side_effect = Exception("S3 failure")

    with pytest.raises(Exception):
        save_image_to_s3(b"processed_image", "12345", "s3://bucket/original_image.png")


@patch("sentinent_demo.handlers.background_removal.get_s3_object_from_uri", return_value=b"image_data")
@patch("sentinent_demo.handlers.background_removal.remove_background_with_bedrock", return_value=b"processed_image")
@patch("sentinent_demo.handlers.background_removal.save_image_to_s3", return_value="s3://bucket/processed_image.png")
@patch("sentinent_demo.handlers.background_removal.update_job_status")
@patch("sentinent_demo.handlers.background_removal.ImageMetadataTable")
def test_background_removal_success(
    mock_metadata_table, mock_update_status, mock_save_image, mock_remove_background, mock_s3_object
):
    event = {"jobId": "12345", "imageUrl": "s3://bucket/original_image.png"}
    context = {}

    result = background_removal(event, context)

    assert result["jobId"] == "12345"
    assert result["imageUrl"] == "s3://bucket/processed_image.png"


@patch("sentinent_demo.handlers.background_removal.get_s3_object_from_uri")
def test_background_removal_invalid_event(mock_s3_object):
    with pytest.raises(ValueError):
        background_removal({"jobId": "12345"}, {})
