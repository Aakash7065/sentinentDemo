import unittest
import uuid
from unittest.mock import Mock, patch
from sentinent_demo.helpers.s3Helper import get_s3_object_from_uri, get_filename_from_s3_url, generate_uuid_from_s3_key

class TestS3Utilities(unittest.TestCase):

    @patch("sentinent_demo.helpers.s3Helper.logger")
    def test_get_s3_object_from_uri_success(self, mock_logger):
        mock_s3_client = Mock()
        mock_s3_client.get_object.return_value = {"Body": Mock(read=Mock(return_value=b"test content"))}

        s3_uri = "s3://test-bucket/path/to/file.txt"
        result = get_s3_object_from_uri(s3_uri, mock_s3_client)

        self.assertEqual(result, b"test content")
        mock_s3_client.get_object.assert_called_once_with(Bucket="test-bucket", Key="path/to/file.txt")
        mock_logger.info.assert_called_once()

    @patch("sentinent_demo.helpers.s3Helper.logger")
    def test_get_s3_object_from_uri_failure(self, mock_logger):
        mock_s3_client = Mock()
        mock_s3_client.get_object.side_effect = Exception("S3 error")

        s3_uri = "s3://test-bucket/path/to/file.txt"
        with self.assertRaises(Exception) as context:
            get_s3_object_from_uri(s3_uri, mock_s3_client)

        self.assertIn("S3 error", str(context.exception))
        mock_logger.error.assert_called_once()

    def test_get_filename_from_s3_url(self):
        s3_url = "s3://test-bucket/path/to/file.txt"
        result = get_filename_from_s3_url(s3_url)
        self.assertEqual(result, "file.txt")

    def test_generate_uuid_from_s3_key(self):
        s3_uri = "s3://test-bucket/path/to/object"
        result = generate_uuid_from_s3_key(s3_uri)
        expected_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, s3_uri))
        self.assertEqual(result, expected_uuid)


if __name__ == "__main__":
    unittest.main()
