import unittest
from unittest.mock import Mock, patch
from datetime import datetime, timezone
from sentinent_demo.helpers.helper import get_current_date_time, update_job_status


class TestUtilityFunctions(unittest.TestCase):

    @patch("sentinent_demo.helpers.helper.datetime")
    def test_get_current_date_time_with_format(self, mock_datetime):
        # Mock current datetime
        mock_datetime.now.return_value = datetime(2024, 11, 26, 10, 0, 0, tzinfo=timezone.utc)
        mock_datetime.timezone = timezone

        # Test with a specific format
        result = get_current_date_time("%Y-%m-%d")
        self.assertEqual(result, "2024-11-26")

    @patch("sentinent_demo.helpers.helper.datetime")
    def test_get_current_date_time_default_format(self, mock_datetime):
        # Mock current datetime
        mock_datetime.now.return_value = datetime(2024, 11, 26, 10, 0, 0, tzinfo=timezone.utc)
        mock_datetime.timezone = timezone

        # Test with default ISO 8601 format
        result = get_current_date_time()
        self.assertEqual(result, "2024-11-26T10:00:00+00:00")

    def test_update_job_status_success(self):
        # Mock metadata client
        mock_metadata_client = Mock()

        # Call the function
        update_job_status("job123", "COMPLETED", mock_metadata_client, {"extra_field": "value"})

        # Assert the method call
        mock_metadata_client.update_status.assert_called_once_with(
            "job123", "COMPLETED", {"extra_field": "value"}
        )

    @patch("sentinent_demo.helpers.helper.logger")
    def test_update_job_status_failure(self, mock_logger):
        # Mock metadata client that raises an exception
        mock_metadata_client = Mock()
        mock_metadata_client.update_status.side_effect = Exception("Database error")

        # Test exception handling
        with self.assertRaises(Exception) as context:
            update_job_status("job123", "FAILED", mock_metadata_client)

        self.assertIn("Database error", str(context.exception))
        mock_logger.error.assert_called_once()


if __name__ == "__main__":
    unittest.main()
