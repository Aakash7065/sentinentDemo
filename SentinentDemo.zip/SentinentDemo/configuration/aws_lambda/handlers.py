# This file is intentionally left blank. It needs to exist otherwise BATS will throw error during transform step
from sentinent_demo.handlers.apis.process_image import process_image
from sentinent_demo.handlers.apis.get_job_status import get_job_status
from sentinent_demo.handlers.apis.get_processed_image import get_processed_image
from sentinent_demo.handlers.object_detection import object_detection
from sentinent_demo.handlers.background_removal import background_removal
from sentinent_demo.handlers.lighting_adjustment import lighting_adjustment
from sentinent_demo.handlers.detail_enhancement import detail_enhancement