import logging
import uuid
from urllib.parse import urlparse

logger = logging.getLogger()
logging.getLogger().setLevel(logging.INFO)

def get_s3_object_from_uri(s3_uri: str, s3_client):
    parsed_uri = urlparse(s3_uri)
    bucket_name = parsed_uri.netloc
    object_key = parsed_uri.path.lstrip('/')
    logger.info(f"bucket_name: {bucket_name}, object_key: {object_key}")
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        return response['Body'].read()
    except Exception as e:
        logger.error(f"Error retrieving object from S3: {e}")
        raise e


def get_filename_from_s3_url(s3_url: str) -> str:
    filename = s3_url.split('/')[-1]
    return filename

def generate_uuid_from_s3_key(s3_uri: str) -> str:
    unique_id = uuid.uuid5(uuid.NAMESPACE_DNS, s3_uri)
    return str(unique_id)