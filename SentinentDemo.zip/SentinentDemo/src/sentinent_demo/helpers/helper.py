import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

def get_current_date_time(date_format: str = None) -> str:
    """
    Gets the current date and time in UTC.

    Args:
        date_format (str): The format string for the date. If None, ISO 8601 format is used.

    Returns:
        str: The formatted date and time in UTC.
    """
    try:
        now = datetime.now(timezone.utc)
        return now.strftime(date_format) if date_format else now.isoformat()
    except Exception as e:
        logger.error("Error formatting date: %s", e)
        raise ValueError("Invalid date format") from e


def update_job_status(job_id: str, status: str, metadata_client, additional_updates: dict = None):
    """
    Updates the job status in the image metadata table.

    Args:
        job_id (str): The unique identifier for the job.
        status (str): The new status of the job.
        metadata_client: A client for interacting with the metadata database.
        additional_updates (dict, optional): Additional fields to update.

    Raises:
        Exception: If updating the job status fails.
    """
    try:
        metadata_client.update_status(job_id, status, additional_updates or {})
        logger.info("Job status updated successfully: JobID=%s, Status=%s", job_id, status)
    except Exception as e:
        logger.error("Failed to update job status: JobID=%s, Error=%s", job_id, e)
        raise
