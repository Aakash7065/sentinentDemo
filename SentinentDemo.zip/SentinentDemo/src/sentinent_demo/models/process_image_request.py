import json
from dataclasses import dataclass


@dataclass
class ProcessImageRequest:
    #S3 uri of the image to process
    image_url: str

    @classmethod
    def from_json(cls, json_data: str):
        if isinstance(json_data, str):
            data = json.loads(json_data)
        else:
            data = json_data
        return cls(**data)

    def to_json(self) -> str:
        return json.dumps(self.__dict__)