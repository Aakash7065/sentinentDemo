from enum import Enum

class JobStatus(Enum):
    SUBMITTED = "submitted"
    AT_OBJECT_DETECTION = "atObjectDetection"
    OBJECT_DETECTION_FAILED = "objectDetectionFailed"
    AT_BACKGROUND_REMOVAL = "atBackgroundRemoval"
    BACKGROUND_REMOVAL_FAILED = "backgroundRemovalFailed"
    AT_DETAIL_ENHANCEMENT = "atDetailEnhancement"
    DETAIL_ENHANCEMENT_FAILED = "detailEnhancementFailed"
    AT_LIGHTNING_ENHANCEMENT = "atLightningEnhancement"
    LIGHTNING_ENHANCEMENT_FAILED = "lightningEnhancementFailed"
    COMPLETED = "completed"