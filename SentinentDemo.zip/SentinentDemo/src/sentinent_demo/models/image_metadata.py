import json
from dataclasses import dataclass
from datetime import datetime, timezone



@dataclass
class ImageMetadata:
    jobId: str
    imageUrl: str
    processingStatus: str
    createdAt: str = None
    lastUpdated: str = None

    @classmethod
    def from_json(cls, json_data: str):
        """Create an instance from a JSON string"""
        if isinstance(json_data, str):
            data = json.loads(json_data)
        else:
            data = json_data
        return cls(**data)

    def to_dynamodb_item(self) -> dict:
        """Convert the instance to a DynamoDB item format"""
        return {
            'imageUrl': self.imageUrl,
            'processingStatus': self.processingStatus,
            'createdAt': self.createdAt or  datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            'lastUpdated': self.lastUpdated or  datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        }
