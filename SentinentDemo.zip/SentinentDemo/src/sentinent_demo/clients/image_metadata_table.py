from typing import Dict, Any, Optional

from botocore.exceptions import ClientError
import logging

from sentinent_demo.clients.boto_clients import get_dynamo_client
from sentinent_demo.constants import constants
from sentinent_demo.helpers.helper import get_current_date_time


class ImageMetadataTable:
    def __init__(self, stage: str, region: str = 'us-east-1'):
        """
        Initialize DynamoDB client for ImageMetadataTable

        Args:
            stage (str): Stage/environment name (dev, prod, etc.)
            region (str): AWS region name, defaults to us-east-1
        """
        self.table_name = f"ImageMetadataTable-{stage}"
        self.dynamodb = get_dynamo_client(constants.REGION)
        self.table = self.dynamodb.Table(self.table_name)
        self.logger = logging.getLogger(__name__)

    def put_item(self, job_id: str, item_data: dict) -> bool:
        """
        Put an item into the DynamoDB table

        Args:
            job_id (str): The job ID (partition key)
            item_data (dict): Dictionary containing item attributes

        Returns:
            bool: True if successful, False if failed
        """
        try:
            # Ensure job_id is included in the item data
            item_data['jobId'] = job_id

            response = self.table.put_item(Item=item_data)
            return response['ResponseMetadata']['HTTPStatusCode'] == 200

        except ClientError as err:
            self.logger.error(
                "Couldn't put item %s in table %s. Here's why: %s: %s",
                job_id,
                self.table_name,
                err.response['Error']['Code'],
                err.response['Error']['Message']
            )
            return False

    def get_item(self, job_id: str) -> dict:
        """
        Get an item from the DynamoDB table

        Args:
            job_id (str): The job ID (partition key)

        Returns:
            dict: Item data if found, empty dict if not found
        """
        try:
            response = self.table.get_item(
                Key={
                    'jobId': job_id
                }
            )

            return response.get('Item', {})

        except ClientError as err:
            self.logger.error(
                "Couldn't get item %s from table %s. Here's why: %s: %s",
                job_id,
                self.table_name,
                err.response['Error']['Code'],
                err.response['Error']['Message']
            )
            return {}

    def update_item(
            self,
            job_id: str,
            updates: Dict[str, Any],
            condition_check: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Update an item in the DynamoDB table

        Args:
            job_id (str): The job ID (partition key)
            updates (dict): Dictionary containing attributes to update
            condition_check (bool): Whether to check if item exists before updating

        Returns:
            Optional[Dict]: Updated item if successful, None if failed

        Raises:
            ValueError: If updates dict is empty
            ClientError: If DynamoDB operation fails
        """
        if not updates:
            raise ValueError("Updates dictionary cannot be empty")

        try:
            # Remove any None values from updates
            updates = {k: v for k, v in updates.items() if v is not None}

            # Prepare update expression and attribute values
            update_parts = []
            expression_attribute_values = {}
            expression_attribute_names = {}

            for key, value in updates.items():
                # Handle nested attributes
                if '.' in key:
                    parts = key.split('.')
                    # Create placeholder for nested attribute
                    attr_path = '#' + '#'.join(parts)
                    for i, part in enumerate(parts):
                        expression_attribute_names[f"#{part}"] = part
                else:
                    attr_path = f"#{key}"
                    expression_attribute_names[f"#{key}"] = key

                placeholder = f":val_{key.replace('.', '_')}"
                update_parts.append(f"{attr_path} = {placeholder}")
                expression_attribute_values[placeholder] = value

            # Add lastUpdated timestamp
            update_parts.append("#lastUpdated = :lastUpdated")
            expression_attribute_names["#lastUpdated"] = "lastUpdated"
            expression_attribute_values[":lastUpdated"] = get_current_date_time("")

            update_expression = "SET " + ", ".join(update_parts)

            # Prepare update parameters
            update_params = {
                'Key': {'jobId': job_id},
                'UpdateExpression': update_expression,
                'ExpressionAttributeValues': expression_attribute_values,
                'ExpressionAttributeNames': expression_attribute_names,
                'ReturnValues': 'ALL_NEW'
            }

            # Add condition expression if needed
            if condition_check:
                update_params['ConditionExpression'] = 'attribute_exists(jobId)'

            # Perform update
            response = self.table.update_item(**update_params)

            # Return updated item
            return response.get('Attributes')

        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'ConditionalCheckFailedException':
                self.logger.warning(f"Item with jobId {job_id} does not exist")
                return None
            else:
                self.logger.error(
                    "Failed to update item %s. Error: %s: %s",
                    job_id,
                    error_code,
                    e.response['Error']['Message']
                )
                raise
        except Exception as e:
            self.logger.error(f"Unexpected error updating item {job_id}: {str(e)}")
            raise

    def update_status(
            self,
            job_id: str,
            status: str,
            additional_updates: Optional[Dict[str, Any]] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Update job status and optionally other attributes

        Args:
            job_id (str): The job ID
            status (str): New status value
            additional_updates (Dict, optional): Additional attributes to update

        Returns:
            Optional[Dict]: Updated item if successful, None if failed
        """
        updates = {'processingStatus': status}
        if additional_updates:
            updates.update(additional_updates)

        return self.update_item(job_id, updates)