import boto3


def get_s3_client(region):
    s3_client = boto3.client('s3', region_name=region)
    return s3_client

def get_dynamo_client(region):
    dynamodb_client = boto3.resource('dynamodb', region_name=region)
    return dynamodb_client

def get_step_function_client(region):
    sfn_client = boto3.client('stepfunctions', region_name=region)
    return sfn_client

def get_rekognition_client(region):
    rekognition_client = boto3.client('rekognition', region_name=region)
    return rekognition_client

def get_bedrock_client(region):
    bedrock_client = boto3.client('bedrock-runtime', region_name=region)
    return bedrock_client