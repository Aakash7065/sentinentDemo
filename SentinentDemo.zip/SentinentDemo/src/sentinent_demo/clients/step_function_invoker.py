import json
import logging
from typing import Dict, Optional

from botocore.exceptions import ClientError

from sentinent_demo.clients.boto_clients import get_step_function_client

logger = logging.getLogger(__name__)
class StepFunctionInvoker:

    def __init__(self, state_machine_arn: str, region: str):
        self.state_machine_arn = state_machine_arn
        self.region = region
        self.sfn_client = get_step_function_client(self.region)

    def start_execution(self, input_data: Dict, execution_name: Optional[str] = None) -> Dict:
        """
        Start asynchronous execution of the state machine

        Args:
            input_data (Dict): Input data for the state machine
            execution_name (str, optional): Unique name for this execution

        Returns:
            Dict: Response from Step Functions containing execution details
        """
        try:
            kwargs = {
                'stateMachineArn': self.state_machine_arn,
                'input': json.dumps(input_data)
            }
            if execution_name:
                kwargs['name'] = execution_name

            response = self.sfn_client.start_execution(**kwargs)

            logger.info(f"Started execution: {response['executionArn']}")
            return response

        except ClientError as e:
            logger.error(f"Failed to start execution: {str(e)}")
            raise