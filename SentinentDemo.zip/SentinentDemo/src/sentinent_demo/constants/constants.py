REGION = 'us-west-2'
STAGE_KEY = 'stage'
STATE_MACHINE_ARN_KEY = "imageProcessingPipelineArn"
RESULT_BUCKET_KEY = "resultBucket"
MODEL_ID = "amazon.titan-image-generator-v2:0"
TARGET_IMAGE_HEIGHT = 1024
TARGET_IMAGE_WIDTH = 1024
MIN_IMAGE_SIZE = 255