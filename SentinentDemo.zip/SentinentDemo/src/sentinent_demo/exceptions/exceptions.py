class NoObjectDetectedException(Exception):
    def __init__(self, message="No object detected"):
        self.message = message
        super().__init__(self.message)

class JobStillInProgressException(Exception):
    def __init__(self, message="Job is still in progress"):
        self.message = message
        super().__init__(self.message)