import io
import logging
import os
import cv2
import numpy as np
from PIL import Image, ImageEnhance

from sentinent_demo.clients.boto_clients import get_s3_client
from sentinent_demo.clients.image_metadata_table import ImageMetadataTable
from sentinent_demo.constants import constants
from sentinent_demo.helpers.helper import update_job_status, get_current_date_time
from sentinent_demo.helpers.s3Helper import get_s3_object_from_uri, get_filename_from_s3_url
from sentinent_demo.models.job_status import JobStatus

# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Initialize AWS clients and configurations
STAGE = os.getenv(constants.STAGE_KEY, "alpha")
s3_client = get_s3_client(constants.REGION)


def calculate_sharpness(image_bytes):
    """
    Calculate the sharpness of an image using the variance of the Laplacian.

    Args:
        image_bytes (bytes): Image data in bytes format.

    Returns:
        float: Sharpness metric.
    """
    try:
        image = Image.open(io.BytesIO(image_bytes)).convert("L")  # Convert to grayscale
        image_np = np.array(image)
        laplacian_var = cv2.Laplacian(image_np, cv2.CV_64F).var()
        logger.info("Calculated sharpness: %.2f", laplacian_var)
        return max(1.0, laplacian_var / 10.0)  # Scale sharpness factor, ensure minimum is 1.0
    except Exception as e:
        logger.error("Error calculating sharpness: %s", e)
        raise


def enhance_product_details(image_bytes):
    """
    Enhance the product details in the image.

    Args:
        image_bytes (bytes): Image data in bytes format.

    Returns:
        bytes: Enhanced image in bytes format.
    """
    try:
        sharpness_factor = calculate_sharpness(image_bytes)
        with Image.open(io.BytesIO(image_bytes)) as image:
            if image.mode != "RGB":
                image = image.convert("RGB")

            enhancer = ImageEnhance.Sharpness(image)
            enhanced_image = enhancer.enhance(sharpness_factor)

            output_buffer = io.BytesIO()
            enhanced_image.save(output_buffer, format="PNG")
            output_buffer.seek(0)

            logger.info("Product details enhanced with sharpness factor: %.2f", sharpness_factor)
            return output_buffer.getvalue()
    except Exception as e:
        logger.error("Error enhancing product details: %s", e)
        raise


def upload_enhanced_image_to_s3(image_bytes, job_id, original_image_url):
    """
    Upload the enhanced image to S3 and generate its URL.

    Args:
        image_bytes (bytes): Enhanced image in bytes.
        job_id (str): Job ID.
        original_image_url (str): URL of the original image.

    Returns:
        str: S3 URL of the enhanced image.
    """
    try:
        enhanced_image_key = (
            f"{get_current_date_time('%Y/%m/%d')}/{job_id}/"
            f"{get_filename_from_s3_url(original_image_url)}"
        )
        bucket_name = os.getenv(constants.RESULT_BUCKET_KEY)

        s3_client.put_object(
            Bucket=bucket_name,
            Key=enhanced_image_key,
            Body=image_bytes,
            ContentType="image/png",
        )

        enhanced_image_url = f"s3://{bucket_name}/{enhanced_image_key}"
        logger.info("Enhanced image uploaded to S3: %s", enhanced_image_url)
        return enhanced_image_url
    except Exception as e:
        logger.error("Error uploading enhanced image to S3: %s", e)
        raise


def detail_enhancement(event, context):
    """
    Main handler for enhancing product details in an image.

    Args:
        event (dict): Contains 'jobId' and 'imageUrl'.
        context: Lambda context object (not used).

    Returns:
        dict: Job ID and URL of the enhanced image.
    """
    job_id = event.get("jobId")
    image_url = event.get("imageUrl")
    if not job_id or not image_url:
        raise ValueError("Both 'jobId' and 'imageUrl' are required.")

    image_metadata_client = ImageMetadataTable(STAGE, constants.REGION)

    try:
        logger.info("Starting detail enhancement for JobID: %s", job_id)
        update_job_status(job_id, JobStatus.AT_DETAIL_ENHANCEMENT.value, image_metadata_client)

        image_bytes = get_s3_object_from_uri(image_url, s3_client)
        enhanced_image_bytes = enhance_product_details(image_bytes)
        enhanced_image_url = upload_enhanced_image_to_s3(enhanced_image_bytes, job_id, image_url)

        update_job_status(job_id, JobStatus.COMPLETED.value, image_metadata_client, {"finalResult": enhanced_image_url})

        return {"jobId": job_id, "imageUrl": enhanced_image_url}
    except Exception as e:
        logger.error("Detail enhancement failed for JobID=%s: %s", job_id, e)
        update_job_status(job_id, JobStatus.DETAIL_ENHANCEMENT_FAILED.value, image_metadata_client)
        raise
