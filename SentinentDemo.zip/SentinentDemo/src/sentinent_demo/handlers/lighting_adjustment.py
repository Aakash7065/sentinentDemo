import io
import logging
import os
import numpy as np
from PIL import Image, ImageEnhance

from sentinent_demo.clients.boto_clients import get_s3_client
from sentinent_demo.clients.image_metadata_table import ImageMetadataTable
from sentinent_demo.constants import constants
from sentinent_demo.helpers.helper import get_current_date_time
from sentinent_demo.helpers.s3Helper import get_s3_object_from_uri, get_filename_from_s3_url
from sentinent_demo.models.job_status import JobStatus
from sentinent_demo.handlers.background_removal import update_job_status

# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Initialize AWS clients and stage
STAGE = os.getenv(constants.STAGE_KEY, "alpha")
s3_client = get_s3_client(constants.REGION)


def calculate_brightness_factor(image, target_brightness=128, max_factor=2.0):
    """
    Calculate brightness adjustment factor based on target brightness.

    Args:
        image (PIL.Image.Image): The input image.
        target_brightness (int): Desired average brightness level.
        max_factor (float): Maximum adjustment factor for brightness.

    Returns:
        float: Brightness adjustment factor.
    """
    try:
        image_np = np.array(image)
        current_brightness = np.mean(image_np)

        if current_brightness < target_brightness:
            return 1 + ((target_brightness - current_brightness) / target_brightness) * (max_factor - 1)
        elif current_brightness > target_brightness:
            return 1 - ((current_brightness - target_brightness) / current_brightness) * (max_factor - 1)
        return 1.0  # No adjustment needed
    except Exception as e:
        logger.error("Error calculating brightness factor: %s", e)
        raise


def enhance_image_lighting(image_bytes):
    """
    Enhance the lighting of an image by adjusting brightness.

    Args:
        image_bytes (bytes): Input image data.

    Returns:
        PIL.Image.Image: Enhanced image object.
    """
    try:
        with Image.open(io.BytesIO(image_bytes)) as image:
            brightness_factor = calculate_brightness_factor(image)
            logger.info("Calculated brightness factor: %.2f", brightness_factor)

            brightness_enhancer = ImageEnhance.Brightness(image)
            return brightness_enhancer.enhance(brightness_factor)
    except Exception as e:
        logger.error("Error enhancing image lighting: %s", e)
        raise


def upload_image_to_s3(image, job_id, original_image_url):
    """
    Save the enhanced image to S3 and return its URL.

    Args:
        image (PIL.Image.Image): Enhanced image object.
        job_id (str): Job identifier.
        original_image_url (str): URL of the original image.

    Returns:
        str: URL of the uploaded enhanced image in S3.
    """
    try:
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        buffer.seek(0)

        enhanced_image_key = (
            f"{get_current_date_time('%Y/%m/%d')}/{job_id}/"
            f"{get_filename_from_s3_url(original_image_url)}"
        )
        bucket_name = os.getenv(constants.RESULT_BUCKET_KEY)

        s3_client.put_object(
            Bucket=bucket_name,
            Key=enhanced_image_key,
            Body=buffer,
            ContentType="image/png",
        )

        return f"s3://{bucket_name}/{enhanced_image_key}"
    except Exception as e:
        logger.error("Error uploading enhanced image to S3: %s", e)
        raise


def lighting_adjustment(event, context):
    """
    Lambda handler for enhancing image lighting.

    Args:
        event (dict): Contains 'jobId' and 'imageUrl'.
        context: Lambda context object (not used).

    Returns:
        dict: Job ID and URL of the enhanced image.
    """
    logger.info("Received event: %s", event)

    job_id = event.get("jobId")
    image_url = event.get("imageUrl")
    if not job_id or not image_url:
        raise ValueError("Both 'jobId' and 'imageUrl' are required.")

    image_metadata_client = ImageMetadataTable(STAGE, constants.REGION)

    try:
        update_job_status(job_id, JobStatus.AT_LIGHTNING_ENHANCEMENT.value, image_metadata_client)
        image_bytes = get_s3_object_from_uri(image_url, s3_client)
        logger.info("Fetched image bytes from S3 for JobID: %s", job_id)

        enhanced_image = enhance_image_lighting(image_bytes)
        logger.info("Image lighting enhancement successful for JobID: %s", job_id)

        enhanced_image_url = upload_image_to_s3(enhanced_image, job_id, image_url)
        logger.info("Enhanced image uploaded to S3 for JobID: %s", job_id)

        update_job_status(job_id, JobStatus.COMPLETED.value, image_metadata_client)

        return {"jobId": job_id, "imageUrl": enhanced_image_url}
    except Exception as e:
        logger.error("Lighting adjustment failed for JobID %s: %s", job_id, e)
        update_job_status(job_id, JobStatus.LIGHTNING_ENHANCEMENT_FAILED.value, image_metadata_client)
        raise
