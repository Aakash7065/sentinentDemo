import io
import logging
import os
from PIL import Image

from sentinent_demo.clients.boto_clients import get_s3_client, get_rekognition_client
from sentinent_demo.clients.image_metadata_table import ImageMetadataTable
from sentinent_demo.constants import constants
from sentinent_demo.exceptions.exceptions import NoObjectDetectedException
from sentinent_demo.helpers.helper import get_current_date_time
from sentinent_demo.helpers.s3Helper import get_s3_object_from_uri, get_filename_from_s3_url
from sentinent_demo.models.job_status import JobStatus

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

s3_client = get_s3_client(constants.REGION)
rekognition_client = get_rekognition_client(constants.REGION)
STAGE = os.getenv(constants.STAGE_KEY, "alpha")


def detect_main_object(image_bytes):
    """
    Detect the main object in the image using AWS Rekognition.
    Returns the instance with the highest confidence.
    """
    try:
        response = rekognition_client.detect_labels(
            Image={"Bytes": image_bytes}, MaxLabels=1, MinConfidence=70
        )
        logger.info("Rekognition response: %s", response)

        best_object = max(
            (instance for label in response["Labels"] for instance in label.get("Instances", [])),
            key=lambda x: x.get("Confidence", 0),
            default=None,
        )
        return best_object
    except Exception as e:
        logger.error("Error during Rekognition label detection: %s", e)
        raise


def crop_and_resize_image(image_bytes, bounding_box, target_size):
    """
    Crop the image to the bounding box, resize it, and pad it to fit target dimensions.
    """
    try:
        image = Image.open(io.BytesIO(image_bytes))
        img_width, img_height = image.size

        left = int(bounding_box["Left"] * img_width)
        top = int(bounding_box["Top"] * img_height)
        right = left + int(bounding_box["Width"] * img_width)
        bottom = top + int(bounding_box["Height"] * img_height)

        cropped_image = image.crop((left, top, right, bottom))
        padded_image = Image.new("RGB", target_size, (255, 255, 255))
        cropped_image.thumbnail(target_size, Image.LANCZOS)
        offset_x = (target_size[0] - cropped_image.width) // 2
        offset_y = (target_size[1] - cropped_image.height) // 2
        padded_image.paste(cropped_image, (offset_x, offset_y))

        buffer = io.BytesIO()
        padded_image.save(buffer, format="PNG")
        buffer.seek(0)
        return buffer.getvalue()
    except Exception as e:
        logger.error("Error during image cropping and resizing: %s", e)
        raise


def upload_to_s3(buffer, job_id, image_url):
    """
    Upload the processed image to S3 and return the new S3 URL.
    """
    try:
        annotated_image_key = (
            f"{get_current_date_time('%Y/%m/%d')}/{job_id}/"
            f"{get_filename_from_s3_url(image_url)}"
        )
        bucket_name = os.getenv(constants.RESULT_BUCKET_KEY)
        s3_client.put_object(
            Bucket=bucket_name,
            Key=annotated_image_key,
            Body=buffer,
            ContentType="image/png",
        )
        return f"s3://{bucket_name}/{annotated_image_key}"
    except Exception as e:
        logger.error("Error during S3 upload: %s", e)
        raise


def object_detection(event, context):
    """
    Main handler for object detection and cropping.
    """
    logger.info("Received event: %s", event)
    job_id = event.get("jobId")
    image_url = event.get("imageUrl")

    if not job_id or not image_url:
        raise ValueError("Missing jobId or imageUrl in the event payload")

    image_metadata_client = ImageMetadataTable(STAGE, constants.REGION)
    try:
        image_metadata_client.update_status(job_id, JobStatus.AT_OBJECT_DETECTION.value)

        image_bytes = get_s3_object_from_uri(image_url, s3_client)
        main_object = detect_main_object(image_bytes)

        if not main_object or "BoundingBox" not in main_object:
            raise NoObjectDetectedException("No object detected in the image.")

        cropped_buffer = crop_and_resize_image(
            image_bytes,
            main_object["BoundingBox"],
            (constants.TARGET_IMAGE_WIDTH, constants.TARGET_IMAGE_HEIGHT),
        )
        annotated_image_url = upload_to_s3(cropped_buffer, job_id, image_url)

        image_metadata_client.update_status(job_id, JobStatus.COMPLETED.value)
        return {"jobId": job_id, "imageUrl": annotated_image_url}
    except Exception as e:
        logger.error("Error during object detection for JobID=%s: %s", job_id, e)
        image_metadata_client.update_status(job_id, JobStatus.OBJECT_DETECTION_FAILED.value)
        raise
