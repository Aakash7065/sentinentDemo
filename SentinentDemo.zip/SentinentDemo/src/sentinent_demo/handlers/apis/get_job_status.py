import json
import logging
import os
from sentinent_demo.clients.image_metadata_table import ImageMetadataTable
from sentinent_demo.constants import constants

# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Retrieve stage from environment variables
STAGE = os.getenv(constants.STAGE_KEY, 'alpha')


def get_job_status(event, context):
    """
    Handle API Gateway requests to retrieve job status.
    """
    logger.info("Received event: %s", event)

    # Extract query parameters
    query_params = event.get('queryStringParameters', {})
    job_id = query_params.get('jobId')

    if not job_id:
        logger.error("Missing jobId in query parameters.")
        return {
            'statusCode': 400,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({"error": "Missing jobId in query parameters"})
        }

    # Retrieve job status from the metadata table
    try:
        image_metadata_client = ImageMetadataTable(STAGE, constants.REGION)
        db_result = image_metadata_client.get_item(job_id)
        job_status = db_result.get("processingStatus")

        if not job_status:
            logger.error(f"No processingStatus found for jobId: {job_id}")
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({"error": "Job not found or no status available"})
            }

        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({"jobStatus": job_status})
        }
    except Exception as e:
        logger.exception("Error retrieving job status")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({"error": "Internal server error", "details": str(e)})
        }
