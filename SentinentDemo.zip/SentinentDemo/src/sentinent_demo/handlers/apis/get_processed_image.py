import json
import logging
import os

from sentinent_demo.clients.image_metadata_table import ImageMetadataTable
from sentinent_demo.constants import constants
from sentinent_demo.exceptions.exceptions import JobStillInProgressException
from sentinent_demo.models.job_status import JobStatus

# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Retrieve stage from environment variables
STAGE = os.getenv(constants.STAGE_KEY, 'alpha')


def get_processed_image(event, context):
    """
    Handle API Gateway requests to retrieve the processed image URL.
    """
    logger.info("Received event: %s", event)

    # Extract query parameters
    query_params = event.get('queryStringParameters', {})
    job_id = query_params.get('jobId')

    if not job_id:
        logger.error("Missing jobId in query parameters.")
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Missing jobId in query parameters"}),
        }

    try:
        # Fetch job data from the metadata table
        image_metadata_client = ImageMetadataTable(STAGE, constants.REGION)
        db_result = image_metadata_client.get_item(job_id)

        job_status = db_result.get("processingStatus")
        if job_status != JobStatus.COMPLETED.value:
            logger.warning(f"Job {job_id} is still in progress: current status is {job_status}")
            raise JobStillInProgressException(f"Job is still in progress, currentStatus is: {job_status}")

        processed_image_url = db_result.get("finalResult")
        if not processed_image_url:
            logger.error(f"No finalResult found for jobId: {job_id}")
            return {
                "statusCode": 404,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Processed image not found"}),
            }

        return {
            "isBase64Encoded": False,
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"processedImageUrl": processed_image_url}),
        }
    except JobStillInProgressException as e:
        return {
            "statusCode": 202,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": str(e)}),
        }
    except Exception as e:
        logger.exception("Error retrieving processed image for jobId=%s", job_id)
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "Internal server error", "details": str(e)}),
        }
