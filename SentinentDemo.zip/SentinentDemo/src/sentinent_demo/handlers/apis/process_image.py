import json
import logging
import os
from io import BytesIO
from PIL import Image

from sentinent_demo.clients.boto_clients import get_s3_client
from sentinent_demo.clients.image_metadata_table import ImageMetadataTable
from sentinent_demo.clients.step_function_invoker import StepFunctionInvoker
from sentinent_demo.constants import constants
from sentinent_demo.helpers.s3Helper import get_s3_object_from_uri, generate_uuid_from_s3_key
from sentinent_demo.models.image_metadata import ImageMetadata
from sentinent_demo.models.job_status import JobStatus
from sentinent_demo.models.process_image_request import ProcessImageRequest

# Setup logging
logger = logging.getLogger()
logging.basicConfig(level=logging.INFO)

# Environment and clients
stage = os.getenv(constants.STAGE_KEY, 'alpha')
s3_client = get_s3_client(constants.REGION)


def is_valid_image(s3_uri: str) -> bool:
    """Check if the image in the given S3 URI is valid."""
    try:
        image_data = get_s3_object_from_uri(s3_uri, s3_client)
        with Image.open(BytesIO(image_data)) as img:
            img.verify()
        return True
    except (IOError, ValueError) as e:
        logger.error(f"Invalid image: {e}")
        raise e


def create_image_metadata(image_url: str) -> ImageMetadata:
    """Create image metadata object from the given image URL."""
    job_id = generate_uuid_from_s3_key(image_url)
    return ImageMetadata(
        jobId=job_id,
        imageUrl=image_url,
        processingStatus=JobStatus.SUBMITTED.value
    )


def start_image_processing(image_metadata: ImageMetadata) -> None:
    """Invoke the step function to process the image."""
    step_function_invoker = StepFunctionInvoker(
        state_machine_arn=os.getenv(constants.STATE_MACHINE_ARN_KEY),
        region=constants.REGION
    )
    step_function_invoker.start_execution(
        input_data={
            "jobId": image_metadata.jobId,
            "imageUrl": image_metadata.imageUrl
        }
    )


def process_image(event, context):
    """Main handler to process the image and initiate the processing flow."""
    logger.info("Received event: %s", event)
    process_image_request = ProcessImageRequest.from_json(event.get('body'))

    # Validate the image
    is_valid_image(process_image_request.image_url)

    # Create image metadata
    image_metadata = create_image_metadata(process_image_request.image_url)

    # Store image metadata
    image_metadata_client = ImageMetadataTable(stage, constants.REGION)
    image_metadata_client.put_item(image_metadata.jobId, image_metadata.to_dynamodb_item())

    # Start image processing
    start_image_processing(image_metadata)

    return {
        "isBase64Encoded": "false",
        "statusCode": "200",
        "headers": {
            'Content-Type': 'application/json'
        },
        "body": json.dumps({'jobId': image_metadata.jobId})
    }
