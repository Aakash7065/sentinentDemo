import base64
import io
import json
import logging
import os
from PIL import Image

from sentinent_demo.clients.boto_clients import get_s3_client, get_bedrock_client
from sentinent_demo.clients.image_metadata_table import ImageMetadataTable
from sentinent_demo.constants import constants
from sentinent_demo.helpers.helper import get_current_date_time, update_job_status
from sentinent_demo.helpers.s3Helper import get_s3_object_from_uri, get_filename_from_s3_url
from sentinent_demo.models.job_status import JobStatus

# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3_client = get_s3_client(constants.REGION)
bedrock_client = get_bedrock_client(constants.REGION)
STAGE = os.getenv("STAGE", "alpha")


def remove_background_with_bedrock(image_bytes):
    """
    Use Bedrock to remove the background from an image.
    """
    try:
        input_image_b64 = base64.b64encode(image_bytes).decode("utf-8")
        request_body = {
            "taskType": "BACKGROUND_REMOVAL",
            "backgroundRemovalParams": {"image": input_image_b64},
        }
        response = bedrock_client.invoke_model(
            modelId=constants.MODEL_ID,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(request_body),
        )
        response_body = json.loads(response["body"].read())

        generated_images = response_body.get("images", [])
        if not generated_images:
            raise ValueError("No image generated in Bedrock response.")

        return base64.b64decode(generated_images[0])

    except Exception as e:
        logger.error("Error during background removal: %s", e)
        raise


def save_image_to_s3(image_bytes, job_id, original_image_url):
    """
    Save the processed image to S3 and return its URL.
    """
    try:
        cleaned_image_key = (
            f"{get_current_date_time('%Y/%m/%d')}/{job_id}/"
            f"{get_filename_from_s3_url(original_image_url)}"
        )
        bucket_name = os.getenv(constants.RESULT_BUCKET_KEY)
        s3_client.put_object(
            Bucket=bucket_name,
            Key=cleaned_image_key,
            Body=image_bytes,
            ContentType="image/png",
        )
        return f"s3://{bucket_name}/{cleaned_image_key}"
    except Exception as e:
        logger.error("Error saving image to S3: %s", e)
        raise


def background_removal(event, context):
    """
    Lambda handler for removing image background.
    """
    logger.info("Event received: %s", event)

    job_id = event.get("jobId")
    image_url = event.get("imageUrl")
    if not job_id or not image_url:
        raise ValueError("Both 'jobId' and 'imageUrl' are required.")

    image_metadata_client = ImageMetadataTable(STAGE, constants.REGION)

    try:
        update_job_status(job_id, JobStatus.AT_BACKGROUND_REMOVAL.value, image_metadata_client)
        image_bytes = get_s3_object_from_uri(image_url, s3_client)
        logger.info("Image fetched from S3: %s", image_url)

        processed_image_bytes = remove_background_with_bedrock(image_bytes)
        logger.info("Background removal successful for JobID=%s", job_id)

        cleaned_image_url = save_image_to_s3(processed_image_bytes, job_id, image_url)
        logger.info("Processed image saved to S3: %s", cleaned_image_url)

        update_job_status(job_id, JobStatus.COMPLETED.value, image_metadata_client)

        return {"jobId": job_id, "imageUrl": cleaned_image_url}
    except Exception as e:
        logger.error("Background removal failed for JobID=%s: %s", job_id, e)
        update_job_status(job_id, JobStatus.BACKGROUND_REMOVAL_FAILED.value, image_metadata_client)
        raise
